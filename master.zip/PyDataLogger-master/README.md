#PyDataLogger


###Overview
---

This program receives multiple data-sending device via internet connection using QThread and QTcpSocket classes. Also, this program receive from a serial port by multithreads.

As May, 2015 is, all functions are not implemented. ( Trying to bring it on ^_^;;)

GPLv3, LGPL license, (C) 2015 Jeong-Whan Lee




